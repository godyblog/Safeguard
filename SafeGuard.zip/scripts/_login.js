
  // Import the functions you need from the SDKs you need
  import { initializeApp } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-app.js";
  import { getAnalytics } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-analytics.js";

  import {
    getAuth,
    fetchSignInMethodsForEmail,
    signInWithEmailAndPassword,
    createUserWithEmailAndPassword,
    sendPasswordResetEmail,
    sendEmailVerification,
    signOut,
    onAuthStateChanged
  } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-auth.js";

  const firebaseConfig = {
    apiKey: "AIzaSyB2IoBPgUnumshpcdg28AvbRMONdSYMEAU",
    authDomain: "safeguard-76e36.firebaseapp.com",
    projectId: "safeguard-76e36",
    storageBucket: "safeguard-76e36.firebasestorage.app",
    messagingSenderId: "639820898310",
    appId: "1:639820898310:web:58bddb80f77ee9c0b6a387",
    measurementId: "G-03Q9HBBQEF"
  };

  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
  const analytics = getAnalytics(app);
  const auth = getAuth(app);
  
  try{
  // HELPERS 
  function showMessage(messageDiv, message, color) {
    const divEl = document.getElementById(messageDiv);
    divEl.textContent = message;
    divEl.style.display ='block';
    divEl.style.color = color;
  }
  
  
  
  
  //LOGIN HANDLER
const  loginForm = document.getElementById('loginForm');
loginForm.addEventListener('submit', async function(event){
  event.preventDefault();
    const submitBtn = loginForm.querySelector('button[type=submit]');
    const email = loginForm.email.value.trim();
    const password = loginForm.password.value;
    
    if(email ==='' || password ===''){
      showMessage('authMessageDiv', 'Please enter your email and password', color='red');
      return
    }
    
    submitBtn.disabled = true; submitBtn.textContent ='Please wait...'
    try {
      const methods = await fetchSignInMethodsForEmail(auth, email);
      console.log(methods); return;
      if(methods.length>=0){
        userCredentials = await signInWithEmailAndPassword(auth, email, password);
      }
    } catch (err) {
      showMessage('authMessageDiv', err.message, "red")
    }
});




const forgotBtn = document.getElementById('forgotBtn');
const cancelReset = document.getElementById('cancel');
const resetSection = document.getElementById('resetSection');
const authSection = document.getElementById('authSection');

forgotBtn.addEventListener('click', ()=>{
  authSection.style.display = "none";
  resetSection.style.display = "block"
})

    cancelReset.addEventListener("click", ()=>{
      authSection.style.display = 'block',
      resetSection.style.display = 'none';
    });
} catch (error) {
  alert(error)
}
/*
const authMessage = document.getElementById('authMessageDiv');
const resetMessage = document.getElementById('resetMessageDiv');


const resetForm = document.getElementById('resetForm');
const resetEmail = document.getElementById('resetEmail');
const 
const sendReset = document.getElementById('sendReset');
const resetError = document.getElementById('resetError');
const resetInfo = document.getElementById('resetInfo');

const verifySection = document.getElementById('verifySection');
const resendVerification = document.getElementById('resendVerification');
const signOutBtn = document.getElementById('signOutBtn');
const verifyMsg = document.getElementById('verifyMsg');

const togglePassword = document.getElementById('togglePassword');

const animated = document.querySelectorAll('[data-animate="true"]');

// ----------------------
// Helpers
// ----------------------
function setStatus(el, text = '', type = 'info') {
  if (!el) return;
  el.hidden = false;
  el.textContent = text;
  el.className = type === 'error' ? 'msg msg-error' : 'msg msg-info';
}
function clearStatus(el) {
  if (!el) return;
  el.hidden = true;
  el.textContent = '';
}
function disableBtn(btn, state = true, text) {
  if (!btn) return;
  btn.disabled = state;
  if (text !== undefined) btn.textContent = text;
}
function debounce(fn, wait = 120) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn.apply(this, args), wait);
  };
}

// Map common firebase error codes to friendly messages
function friendlyError(err) {
  if (!err) return 'An unknown error occurred.';
  const code = err.code || '';
  if (code.includes('invalid-email')) return 'Invalid email address.';
  if (code.includes('user-not-found')) return 'No account found for that email.';
  if (code.includes('wrong-password')) return 'Incorrect password.';
  if (code.includes('too-many-requests')) return 'Too many attempts — please wait and try again later.';
  if (code.includes('internal-error')) return 'Internal error. Please try again.';
  return err.message || 'Operation failed. Try again.';
}

// ----------------------
// Password visibility toggle
// ----------------------
if (togglePassword) {
  togglePassword.addEventListener('click', () => {
    const pressed = togglePassword.getAttribute('aria-pressed') === 'true';
    if (pressed) {
      passwordInput.type = 'password';
      togglePassword.setAttribute('aria-pressed', 'false');
      togglePassword.setAttribute('aria-label', 'Show password');
      togglePassword.innerHTML = '<i class="fas fa-eye"></i>';
    } else {
      passwordInput.type = 'text';
      togglePassword.setAttribute('aria-pressed', 'true');
      togglePassword.setAttribute('aria-label', 'Hide password');
      togglePassword.innerHTML = '<i class="fas fa-eye-slash"></i>';
    }
  });
}

// ----------------------
// Core: check email exists in Auth then sign in
// ----------------------
loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  clearStatus(msgError);
  clearStatus(msgInfo);

  const email = (emailInput.value || '').trim(); //.toLowerCase();
  const password = (passwordInput.value || '').trim();

  if (!email || !password) {
    setStatus(msgError, 'Please enter both email and password.', 'error');
    return;
  }

  // UI state
  disableBtn(submitBtn, true, 'Checking...');

  try {
    // 1) Check sign-in methods for email (does the email exist in Firebase Auth?)
    const methods = await fetchSignInMethodsForEmail(auth, email);

    /*if (!methods || methods.length === 0) {
      // email not registered in Firebase Auth
      setStatus(msgError, 'No account found for that email. Please sign up first.', 'error');
      disableBtn(submitBtn, false, 'Sign in');
      return;
    } 

    // 2) The email exists — proceed to sign in with email & password
    disableBtn(submitBtn, true, 'Signing in...');
    const credential = await signInWithEmailAndPassword(auth, email, password);
    const user = credential.user;

    if (!user) {
      setStatus(msgError, 'Sign in failed. Try again.', 'error');
      disableBtn(submitBtn, false, 'Sign in');
      return;
    }

    // 3) If email not verified, show verify UI and stop redirect
    if (!user.emailVerified) {
      verifySection.classList.remove('hidden');
      verifySection.setAttribute('aria-hidden', 'false');
      setStatus(verifyMsg, 'Your email is not verified. Check your inbox or resend verification.', 'info');
      // keep user signed in or sign out depending on policy; here we leave signed in but block redirect
      disableBtn(submitBtn, false, 'Sign in');
      return;
    }

    // 4) Email is verified: store minimal user info to sessionStorage and redirect
    const sessionUser = {
      uid: user.uid,
      email: user.email,
      displayName: user.displayName || null,
      lastLogin: new Date().toISOString()
    };
    sessionStorage.setItem('safeguard_user', JSON.stringify(sessionUser));

    setStatus(msgInfo, 'Sign in successful. Redirecting...', 'info');

    // small delay to let user see message then redirect
    setTimeout(() => {
      window.location.href = '/index.html';
    }, 700);

  } catch (err) {
    console.error('Login flow error:', err);
    setStatus(msgError, friendlyError(err), 'error');
  } finally {
    disableBtn(submitBtn, false, 'Sign in');
  }
});

// ----------------------
// Password reset flow
// ----------------------
if (forgotBtn) {
  forgotBtn.addEventListener('click', () => {
    document.getElementById('authSection').style.display = 'none';
    resetSection.classList.remove('hidden');
    resetSection.setAttribute('aria-hidden', 'false');
    resetEmail.focus();
  });
}

if (cancelReset) {
  cancelReset.addEventListener('click', () => {
    resetSection.classList.add('hidden');
    resetSection.setAttribute('aria-hidden', 'true');
    clearStatus(resetError);
    clearStatus(resetInfo);
  });
}

if (resetForm) {
  resetForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearStatus(resetError);
    clearStatus(resetInfo);

    const email = (resetEmail.value || '').trim().toLowerCase();
    if (!email) {
      setStatus(resetError, 'Enter your account email.', 'error');
      return;
    }

    sendReset.disabled = true;
    sendReset.textContent = 'Checking...';

    try {
      // Check email existence before sending reset
      const methods = await fetchSignInMethodsForEmail(auth, email);
      if (!methods || methods.length === 0) {
        setStatus(resetError, 'No account found for that email.', 'error');
        sendReset.disabled = false;
        sendReset.textContent = 'Send reset link';
        return;
      }

      // Send password reset
      await sendPasswordResetEmail(auth, email);
      setStatus(resetInfo, 'Password reset link sent. Check your inbox.', 'info');
    } catch (err) {
      console.error('Reset error', err);
      setStatus(resetError, friendlyError(err), 'error');
    } finally {
      sendReset.disabled = false;
      sendReset.textContent = 'Send reset link';
    }
  });
}

// ----------------------
// Resend verification email (for signed-in but unverified users)
// ----------------------
if (resendVerification) {
  resendVerification.addEventListener('click', async () => {
    clearStatus(verifyMsg);
    try {
      const user = auth.currentUser;
      if (!user) {
        setStatus(verifyMsg, 'No signed-in user available. Please sign in first.', 'error');
        return;
      }
      await sendEmailVerification(user);
      setStatus(verifyMsg, 'Verification email sent. Check your inbox.', 'info');
    } catch (err) {
      console.error('Resend verification error', err);
      setStatus(verifyMsg, friendlyError(err), 'error');
    }
  });
}

// Sign out button in verify panel
if (signOutBtn) {
  signOutBtn.addEventListener('click', async () => {
    try {
      await signOut(auth);
      sessionStorage.removeItem('safeguard_user');
      verifySection.classList.add('hidden');
      verifySection.setAttribute('aria-hidden', 'true');
      setStatus(msgInfo, 'Signed out.', 'info');
    } catch (err) {
      console.error('Sign out error', err);
      setStatus(msgError, 'Sign out failed.', 'error');
    }
  });
}

// ----------------------
// Auth state listener
// Keep UI consistent if auth state changes (user signed-in elsewhere, etc.)
onAuthStateChanged(auth, (user) => {
  if (!user) return;
  // if user becomes verified while on page, proceed to redirect
  if (user.emailVerified) {
    // ensure session stored
    const s = sessionStorage.getItem('safeguard_user');
    if (!s) {
      const sessionUser = { uid: user.uid, email: user.email, displayName: user.displayName || null, lastLogin: new Date().toISOString() };
      sessionStorage.setItem('safeguard_user', JSON.stringify(sessionUser));
    }
    // redirect
    window.location.href = '/index.html';
  } else {
    verifySection.classList.remove('hidden');
    verifySection.setAttribute('aria-hidden', 'false');
    setStatus(verifyMsg, 'Your email is not verified. Resend verification if needed.', 'info');
  }
});

// ----------------------
// Scroll animations (replayable on re-entry)
// ----------------------
function updateInView() {
  animated.forEach(el => {
    const r = el.getBoundingClientRect();
    if (r.top < window.innerHeight - 80 && r.bottom > 0) {
      el.classList.add('in-view');
    } else {
      el.classList.remove('in-view');
    }
  });
}
window.addEventListener('scroll', debounce(updateInView, 60), { passive: true });
window.addEventListener('resize', debounce(updateInView, 150));
updateInView(); */